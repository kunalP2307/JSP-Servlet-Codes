package demo;
public class User{
	public User(){
	}
}
